package com.mcp.lottery.mapper;


import com.mcp.lottery.model.PlatGame;
import com.mcp.lottery.util.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PlatGameMapper extends BaseMapper<PlatGame>{
}
