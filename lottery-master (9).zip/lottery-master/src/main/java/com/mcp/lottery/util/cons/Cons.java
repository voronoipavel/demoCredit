package com.mcp.lottery.util.cons;

public class Cons {

    public static final String SUCCESS="投注成功";


    public static class Game{
        public static final String CQSSC="chongqingshishicai";
        public static final String TXFFC="T01";
    }


}
