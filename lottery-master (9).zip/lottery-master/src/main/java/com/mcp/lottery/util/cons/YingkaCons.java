package com.mcp.lottery.util.cons;

import java.util.HashMap;
import java.util.Map;

public class YingkaCons {

    public static String PLAY_FFC = "60";

    public static Map<String, String> TOU_ZHU = new HashMap() {{
        put("111", "大,,,,");
        put("112", "小,,,,");
        put("121", "单,,,,");
        put("122", "双,,,,");

        put("211", ",大,,,");
        put("212", ",小,,,");
        put("221", ",单,,,");
        put("222", ",双,,,");

        put("311", ",,大,,");
        put("312", ",,小,,");
        put("321", ",,单,,");
        put("322", ",,双,,");

        put("411", ",,,大,");
        put("412", ",,,小,");
        put("421", ",,,单,");
        put("422", ",,,双,");

        put("511", ",,,,大");
        put("512", ",,,,小");
        put("521", ",,,,单");
        put("522", ",,,,双");
    }};

    public static String PLAY_SSC = "1";


}
