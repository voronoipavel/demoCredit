package com.mcp.lottery.controller;

/**
 * 交易相关
 */
public class TradeController {
}
