package com.mcp.lottery.mapper;

import com.mcp.lottery.model.UserRule;
import com.mcp.lottery.util.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserRuleMapper extends BaseMapper<UserRule> {
}
