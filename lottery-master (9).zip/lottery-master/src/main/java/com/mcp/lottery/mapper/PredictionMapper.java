package com.mcp.lottery.mapper;

import com.mcp.lottery.model.Prediction;
import com.mcp.lottery.util.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PredictionMapper extends BaseMapper<Prediction>{
}
