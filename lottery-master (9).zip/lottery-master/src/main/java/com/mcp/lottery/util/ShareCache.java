package com.mcp.lottery.util;


import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ShareCache {

    public static List<JSONObject> taiyanRate = new ArrayList<>();

}
