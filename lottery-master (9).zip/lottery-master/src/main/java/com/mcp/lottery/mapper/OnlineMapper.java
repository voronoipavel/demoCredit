package com.mcp.lottery.mapper;


import com.mcp.lottery.model.Online;
import com.mcp.lottery.util.BaseMapper;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface OnlineMapper extends BaseMapper<Online> {

}
